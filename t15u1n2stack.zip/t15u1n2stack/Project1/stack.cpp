#include <fstream>
#include <stack>
using namespace std;

int main() {
	stack<int> t, t1, w;  //t - numbers, t1 - dop stack, w - '+' numbers 
	int chisla, sum = 0;

	ifstream go("numbers.txt");
	ofstream run("final.txt");

	while (go >> chisla) {
		t.push(chisla);
	}
	go.close();

	while (!t.empty()) {
		int num = t.top();
		t1.push(num);
		if (num > 0) {
			w.push(num);  //+ numbers are writing 
			sum += num;
		}
		t.pop();
	}

	run << "+ numbers: \n";
	
	while (!w.empty()) {
		run << w.top() << " ";
		w.pop();
	}
	run << "\n\nsumma of + numbers: " << sum << "\n";
	run.close();
	return 0;
}